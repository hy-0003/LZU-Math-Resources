#include<bits/stdc++.h>
#include"hhh.h"
using namespace std;
/*class ben
{
public:
    virtual double v()=0;
    virtual void printt()=0;
};
class hhh:public ben
{
public:
    double x;
    double y;
    double z;
    virtual double v();
    virtual void printt();
};
class rrr:public ben
{
public:
    double r;
    virtual double v();
    virtual void printt();
};
class rh:public ben
{
public:
    double r;
    double h;
    virtual double v();
    virtual void printt();
};


double rrr::v()
{
    return 3.14*1.33*r*r*r;
}
void rrr::printt()
{
    cout<<"����������Ϊ��"<<v()<<endl;
}

double hhh::v()
{
    return x*y*z;
}
void hhh::printt()
{
    cout<<"������������Ϊ��"<<v()<<endl;
}


double rh::v()
{
    return 0.33*3.14*r*r*h;
}
void rh::printt()
{
    cout<<"��Բ׶�����Ϊ��"<<v()<<endl;
}


int xcompare(const void * s1,const void * s2)
{
    ben ** p1=(ben ** )s1;
    ben ** p2=(ben ** )s2;
    double a1=(* p1)->v();
    double a2=(* p2)->v();
    if(a1<a2)
        return -1;
    else if(a1==a2)
        return 0;
    else
        return 1;
}*/
int main()
{
    int n;
    hhh * phhh;rrr * prrr;rh * prh;
    cout<<"���������账���ļ����������"<<endl;
    cin>>n;
    ben * a[n];
    for(int i=0;i<n;++i)
    {
        char x;
        cin>>x;
        if(x=='Q')
        {
            prrr=new rrr();
            cin>>prrr->r;
            a[i]=prrr;
        }
        if(x=='L')
        {
            phhh=new hhh;
            cin>>phhh->x>>phhh->y>>phhh->z;
            a[i]=phhh;
        }
        if(x=='Y')
        {
            prh=new rh;
            cin>>prh->r>>prh->h;
            a[i]=prh;
        }
    }
    cout<<"���潫�������С��������"<<endl;
    qsort(a,n,sizeof(ben *),xcompare);
    for(int i=0;i<n;++i)
    {
        a[i]->printt();
        delete a[i];
    }
    return 0;
}
