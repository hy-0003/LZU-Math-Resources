#ifndef STUDENT_H
#define STUDENT_H

#include<iostream>
#include<string.h>
using namespace std;

class student{
private:
    string name;
    int id;
public:
    student(string tmp_name,int tmp_id);
    print_info();
};
class postgraduate:public student{
private:
    string grade;
    string research;
public:
    postgraduate(string tmp_name,int tmp_id,string tmp_grade,string tmp_research);
    print_info();
};
class worker{
private:
    string name;
    int salary;
public:
    worker(string tmp_name,int tmp_salary);
    print_info();
};
class job_postgraduate:virtual public worker,postgraduate{
private:
    float proportion;
public:
    job_postgraduate(string tmp_name,int tmp_id,string tmp_grade,string tmp_research,int tmp_salary,int tmp_pro);
    print_info();
};
#endif // STUDENT_H
