#include <iostream>
#include <string.h>
#include"student.h"
using namespace std;

int main()
{
    student a("Mike",4396);
    a.print_info();
    postgraduate b("Simon",1557,"��һ","��ѧ");
    b.print_info();
    worker c("July",8888);
    c.print_info();
    job_postgraduate d("Wanna",7777,"���","Ӣ��",1234,4444);
    d.print_info();
    return 0;
}
