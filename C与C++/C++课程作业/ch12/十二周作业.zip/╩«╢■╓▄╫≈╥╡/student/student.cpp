#include"student.h"

student::student(string tmp_name,int tmp_id):name(tmp_name),id(tmp_id){};
student::print_info(){
    cout<<"����:"<<name<<endl<<"ѧ��:"<<id<<endl;
}
postgraduate::postgraduate(string tmp_name,int tmp_id,string tmp_grade,string tmp_research):student(tmp_name,tmp_id),grade(tmp_grade),research(tmp_research){};
postgraduate::print_info(){
    student::print_info();
    cout<<"�꼶:"<<grade<<endl<<"�о�����:"<<research<<endl;
}
worker::worker(string tmp_name,int tmp_salary):name(tmp_name),salary(tmp_salary){};
worker::print_info(){
    cout<<"����:"<<name<<endl<<"����:"<<salary<<endl;
}
job_postgraduate::job_postgraduate(string tmp_name,int tmp_id,string tmp_grade,string tmp_research,int tmp_salary,int tmp_pro):postgraduate(tmp_name,tmp_id,tmp_grade,tmp_research),worker(tmp_name,tmp_salary){};
job_postgraduate::print_info(){
    postgraduate::print_info();
    worker::print_info();
}

