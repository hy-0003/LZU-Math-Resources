#ifndef 5_31_H_INCLUDED
#define 5_31_H_INCLUDED
static int stunumber=1000
void s_shuchu(string _objectnum)
class student
class s
void s_shuchu(s s1,student stu[],string _objectnum)
void s::couttnum(student k[],int sum)
void s::couttave(student k[],int sum)
void s::coutt(student k[],int sum,string _objectnum)
student::student()
student::student(string _name,int _age)
student::student(int score_number)
student::student(student & a)
student::~student()


#endif // 5_31_H_INCLUDED
