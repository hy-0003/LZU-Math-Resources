#include<bits/stdc++.h>
using namespace std;
int main()
{
    double a;
    while(cin>>a)
    {
        cout<<fixed<<setprecision(6)<<a<<endl;
        cout<<scientific<<setprecision(5)<<a<<endl;
    }
    return 0;
}
